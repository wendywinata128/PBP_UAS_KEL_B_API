(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[8],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/user_pages/about_us_user.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/user_pages/about_us_user.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "aboutUs",
  data: function data() {
    return {
      restokuStyle: {
        backgroundColor: "#FEE8CB"
      },
      titleContent: {
        greetings: "GREETINGS FROM OUR OWNER!",
        delivery: "DELIVERY SERVICE",
        contact: "CONTACT US"
      },
      contactUs: {
        address: "Jalan Parangtritis No. 76, Mantrijeron, Yogyakarta, 55143",
        phone: "0816 227 8890",
        mail: "restokujogja@gmail.com"
      }
    };
  },
  methods: {}
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/user_pages/about_us_user.vue?vue&type=style&index=0&lang=css&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/user_pages/about_us_user.vue?vue&type=style&index=0&lang=css& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n@import url();\nh1 {\n    font-size: 50px;\n    font-weight: 550;\n}\n.content {\n    margin: 20px 50px;\n}\nh4 {\n    font-weight: 550;\n    border-bottom: 4px solid #FAA84B;\n}\n.owner_photo,\n.delivery_photo {\n    border-radius: 10px;\n    box-shadow: 6px 6px 20px 2px rgba(0, 0, 0, 0.25);\n}\n.owner_photo {\n    margin: 10px 20px 20px 0px;\n    float: left;\n    width: 400px;\n}\n.delivery_photo {\n    margin: 0px 0px 20px 20px;\n    float: right;\n    width: 210px;\n}\n.logo_restoku {\n    margin: 30px 20px 30px 0px;\n    width: 180px;\n}\n.contact {\n    margin-right: 20px;\n    float: left;\n    width: 25px;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/user_pages/about_us_user.vue?vue&type=style&index=0&lang=css&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/user_pages/about_us_user.vue?vue&type=style&index=0&lang=css& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./about_us_user.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/user_pages/about_us_user.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/user_pages/about_us_user.vue?vue&type=template&id=f11850f8&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/user_pages/about_us_user.vue?vue&type=template&id=f11850f8& ***!
  \**********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "about_us", style: _vm.restokuStyle },
    [
      _c(
        "b-carousel",
        {
          staticStyle: { "text-shadow": "1px 1px 2px #333" },
          attrs: {
            id: "carousel-1",
            interval: 4000,
            controls: "",
            indicators: "",
            "img-width": "1024",
            "img-height": "480"
          }
        },
        [
          _c(
            "b-carousel-slide",
            {
              staticStyle: { height: "500px" },
              attrs: {
                "img-src": "/img/about_us_carousel/restaurant_photo.jpg",
                alt: "Restaurant Photo"
              }
            },
            [
              _c("h1", [
                _vm._v("HI THERE, "),
                _c("br"),
                _vm._v(" WELCOME TO RESTOKU!")
              ])
            ]
          ),
          _vm._v(" "),
          _c(
            "b-carousel-slide",
            {
              staticStyle: { height: "500px" },
              attrs: {
                "img-src": "/img/about_us_carousel/cooking.jpg",
                alt: "Cooking"
              }
            },
            [
              _c("h1", [
                _vm._v("HI THERE, "),
                _c("br"),
                _vm._v(" WELCOME TO RESTOKU!")
              ])
            ]
          ),
          _vm._v(" "),
          _c(
            "b-carousel-slide",
            {
              staticStyle: { height: "500px" },
              attrs: {
                "img-src": "/img/about_us_carousel/eat_together.jpg",
                alt: "Eat Together"
              }
            },
            [
              _c("h1", [
                _vm._v("HI THERE, "),
                _c("br"),
                _vm._v(" WELCOME TO RESTOKU!")
              ])
            ]
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "content" },
        [
          _c("h4", { staticStyle: { width: "400px" } }, [
            _vm._v(_vm._s(_vm.titleContent.greetings))
          ]),
          _vm._v(" "),
          _c("v-img", {
            staticClass: "owner_photo",
            attrs: { src: "/img/logo/owner.jpg" }
          }),
          _vm._v(" "),
          _vm._m(0),
          _vm._v(" "),
          _c("p", [
            _vm._v(
              "Since January 1, 2007, we have been dedicated to bringing an authentic dining experience to the people of Yogyakarta.  Dine-in or carry-out, we promise we serve you the best!\n            Our menu is thoughtfully designed to bring customers a variety of the many tastes of Indonesian to Western foods.  From fried rice to salad dishes, we offer a wide range of choices for any taste."
            )
          ]),
          _vm._v(" "),
          _c("p", [
            _vm._v(
              "Our passion not only serve good and delicious food, but also concern to the \n            customer happiness & satisfaction, more than that we want the generation coming keep the old cooking tradition and enjoy the warmness of homecooked meals."
            )
          ]),
          _vm._v(" "),
          _c(
            "v-btn",
            { staticClass: "white--text", attrs: { color: "#FAA84B" } },
            [_vm._v("ORDER NOW")]
          ),
          _vm._v(" "),
          _c("v-divider", { staticClass: "mt-15 mb-5" }),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "delivery", staticStyle: { "text-align": "right" } },
            [
              _c("h4", { staticStyle: { display: "inline" } }, [
                _vm._v(_vm._s(_vm.titleContent.delivery))
              ]),
              _vm._v(" "),
              _c("br"),
              _c("br"),
              _vm._v(" "),
              _c("v-img", {
                staticClass: "delivery_photo",
                attrs: { src: "/img/menu/besek.jpg", width: "350px" }
              }),
              _vm._v(" "),
              _vm._m(1),
              _vm._v(" "),
              _c("p", [
                _vm._v(
                  "By the way, for delivery and take away packaging we use bamboo box (in Indonesia we call it besek) to save the planet."
                )
              ])
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider", {
            staticClass: "mb-5",
            staticStyle: { "margin-top": "290px" }
          }),
          _vm._v(" "),
          _c("div", { staticClass: "d-flex justify-space-around" }, [
            _c(
              "div",
              [
                _c("h4", { staticStyle: { width: "170px" } }, [
                  _vm._v(_vm._s(_vm.titleContent.contact))
                ]),
                _vm._v(" "),
                _c("v-img", {
                  staticClass: "logo_restoku",
                  attrs: { src: "/img/logo/logo_restoku.png" }
                }),
                _vm._v(" "),
                _c("v-img", {
                  staticClass: "contact",
                  attrs: { src: "/img/pin.png" }
                }),
                _vm._v(" "),
                _c("p", [_vm._v(_vm._s(_vm.contactUs.address))]),
                _vm._v(" "),
                _c("v-img", {
                  staticClass: "contact",
                  attrs: { src: "/img/social_media/whatsapp.png" }
                }),
                _vm._v(" "),
                _c("p", [_vm._v(_vm._s(_vm.contactUs.phone))]),
                _vm._v(" "),
                _c("v-img", {
                  staticClass: "contact",
                  attrs: { src: "/img/social_media/gmail.png" }
                }),
                _vm._v(" "),
                _c("p", [_vm._v(_vm._s(_vm.contactUs.mail))])
              ],
              1
            ),
            _vm._v(" "),
            _vm._m(2)
          ])
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("strong", [
        _vm._v("Hello! Thank you for coming to Restoku's website.")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", { staticClass: "mt-1" }, [
      _vm._v("Thinking about delivery food? We provide a "),
      _c("strong", [
        _vm._v("24 hours delivery service for Yogyakarta area only")
      ]),
      _vm._v(
        '. So you can order anytime you want!\n                Simply click "Menu" on this website and add your order to cart. For payment methods, you can choose OVO, DANA, or LinkAja. We are also available at GoFood and GrabFood application, \n                we are just one click away from you.'
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", [
      _c("iframe", {
        staticStyle: { border: "0" },
        attrs: {
          src:
            "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3952.7173081970973!2d110.36583741440234!3d-7.8197174943652445!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a57a33d12c8db%3A0x255fd3a34cf7cf10!2sJl.%20Parangtritis%20No.76%2C%20Mantrijeron%2C%20Kec.%20Mergangsan%2C%20Kota%20Yogyakarta%2C%20Daerah%20Istimewa%20Yogyakarta%2055143!5e0!3m2!1sen!2sid!4v1606204368725!5m2!1sen!2sid",
          width: "600",
          height: "350",
          frameborder: "0",
          allowfullscreen: "",
          "aria-hidden": "false",
          tabindex: "0"
        }
      })
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/pages/user_pages/about_us_user.vue":
/*!*********************************************************!*\
  !*** ./resources/js/pages/user_pages/about_us_user.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _about_us_user_vue_vue_type_template_id_f11850f8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./about_us_user.vue?vue&type=template&id=f11850f8& */ "./resources/js/pages/user_pages/about_us_user.vue?vue&type=template&id=f11850f8&");
/* harmony import */ var _about_us_user_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./about_us_user.vue?vue&type=script&lang=js& */ "./resources/js/pages/user_pages/about_us_user.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _about_us_user_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./about_us_user.vue?vue&type=style&index=0&lang=css& */ "./resources/js/pages/user_pages/about_us_user.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _about_us_user_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _about_us_user_vue_vue_type_template_id_f11850f8___WEBPACK_IMPORTED_MODULE_0__["render"],
  _about_us_user_vue_vue_type_template_id_f11850f8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/user_pages/about_us_user.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/pages/user_pages/about_us_user.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/pages/user_pages/about_us_user.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_about_us_user_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./about_us_user.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/user_pages/about_us_user.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_about_us_user_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/user_pages/about_us_user.vue?vue&type=style&index=0&lang=css&":
/*!******************************************************************************************!*\
  !*** ./resources/js/pages/user_pages/about_us_user.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_about_us_user_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vue-loader/lib??vue-loader-options!./about_us_user.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/user_pages/about_us_user.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_about_us_user_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_about_us_user_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_about_us_user_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_about_us_user_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/pages/user_pages/about_us_user.vue?vue&type=template&id=f11850f8&":
/*!****************************************************************************************!*\
  !*** ./resources/js/pages/user_pages/about_us_user.vue?vue&type=template&id=f11850f8& ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_about_us_user_vue_vue_type_template_id_f11850f8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./about_us_user.vue?vue&type=template&id=f11850f8& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/user_pages/about_us_user.vue?vue&type=template&id=f11850f8&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_about_us_user_vue_vue_type_template_id_f11850f8___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_about_us_user_vue_vue_type_template_id_f11850f8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);