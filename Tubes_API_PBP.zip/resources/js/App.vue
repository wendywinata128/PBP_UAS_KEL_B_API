<template>
    <v-app>
        <router-view></router-view>
    </v-app>
</template>

<script>
export default {
    name:'app',
    data(){
        return{

        }
    },
    created(){
    }
}
</script>

<style>
    table{
        table-layout: fixed;
    }
</style>