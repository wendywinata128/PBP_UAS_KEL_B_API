<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\Semester 5\Z_Tubes API\PBP\Tubes_API_PBP\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>