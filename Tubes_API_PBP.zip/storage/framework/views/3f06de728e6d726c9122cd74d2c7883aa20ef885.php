<?php echo e($slot); ?>

<?php /**PATH E:\Semester 5\Z_Tubes API\Tubes_API\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>