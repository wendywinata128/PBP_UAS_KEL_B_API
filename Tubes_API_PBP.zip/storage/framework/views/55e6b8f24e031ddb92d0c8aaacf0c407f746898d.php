<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\Semester 5\Z_Tubes API\Tubes_API\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>