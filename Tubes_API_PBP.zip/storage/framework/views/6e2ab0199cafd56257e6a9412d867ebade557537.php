<?php echo e($slot); ?>

<?php /**PATH E:\Semester 5\Z_Tubes API\PBP\Tubes_API_PBP\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>